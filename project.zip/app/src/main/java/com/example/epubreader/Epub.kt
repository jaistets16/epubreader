package com.example.epubreader

import android.net.Uri
import android.text.Html
import java.io.File
import java.util.zip.ZipFile

object Epub {
    private fun attr(tag: String, name: String): String? =
        Regex("""\b$name\s*=\s*["']([^"']*)["']""", RegexOption.IGNORE_CASE).find(tag)?.groupValues?.get(1)

    /** Returns chapters, each a list of speakable chunks. */
    fun load(file: File): List<List<String>> {
        ZipFile(file).use { zip ->
            fun read(path: String): String? =
                zip.getEntry(path)?.let { zip.getInputStream(it).bufferedReader().readText() }

            val container = read("META-INF/container.xml") ?: error("Not an EPUB")
            val opfPath = attr(container, "full-path") ?: error("No OPF")
            val opf = read(opfPath) ?: error("OPF missing")
            val base = opfPath.substringBeforeLast('/', "")

            val manifest = HashMap<String, String>()
            Regex("<item\\b[^>]*>", RegexOption.IGNORE_CASE).findAll(opf).forEach {
                val id = attr(it.value, "id"); val href = attr(it.value, "href")
                if (id != null && href != null) manifest[id] = href
            }
            val spine = Regex("<itemref\\b[^>]*>", RegexOption.IGNORE_CASE).findAll(opf)
                .mapNotNull { attr(it.value, "idref") }.toList()

            val out = ArrayList<List<String>>()
            for (id in spine) {
                val href = Uri.decode(manifest[id] ?: continue).substringBefore('#')
                val path = normalize(if (base.isEmpty()) href else "$base/$href")
                val html = read(path) ?: continue
                val text = toText(html)
                if (text.length < 20) continue
                val chunks = chunk(text)
                if (chunks.isNotEmpty()) out.add(chunks)
            }
            return out
        }
    }

    private fun normalize(p: String): String {
        val parts = ArrayList<String>()
        for (s in p.split('/')) when (s) { "", "." -> {}; ".." -> if (parts.isNotEmpty()) parts.removeAt(parts.size - 1); else -> parts.add(s) }
        return parts.joinToString("/")
    }

    private fun toText(html: String): String {
        var h = html.replace(Regex("(?is)<head.*?</head>"), "")
            .replace(Regex("(?is)<(style|script).*?</\\1>"), "")
            .replace(Regex("(?i)</(p|div|h[1-6]|li|br|tr)>|<br\\s*/?>"), "\n")
        h = Html.fromHtml(h, Html.FROM_HTML_MODE_LEGACY).toString()
        return h.replace('\uFFFC', ' ').replace('\u00A0', ' ')
            .lines().map { it.trim().replace(Regex("\\s+"), " ") }
            .filter { it.isNotEmpty() }.joinToString("\n")
    }

    private fun chunk(text: String, target: Int = 140, max: Int = 350): List<String> {
        val out = ArrayList<String>()
        for (para in text.split('\n')) {
            val sentences = para.split(Regex("(?<=[.!?…”\"])\\s+"))
            val cur = StringBuilder()
            fun flush() { if (cur.isNotBlank()) out.add(cur.toString().trim()); cur.clear() }
            for (s0 in sentences) {
                var s = s0
                while (s.length > max) {
                    var cut = s.lastIndexOf(',', max).takeIf { it > 40 } ?: s.lastIndexOf(' ', max)
                    if (cut <= 0) cut = max
                    flush(); out.add(s.substring(0, cut + 1).trim()); s = s.substring(cut + 1).trim()
                }
                if (cur.length + s.length > max) flush()
                cur.append(s).append(' ')
                if (cur.length >= target) flush()
            }
            flush()
        }
        return out.filter { it.any(Char::isLetterOrDigit) }
    }
}
