package com.example.epubreader

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.media.PlaybackParams
import com.k2fsa.sherpa.onnx.*
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.LinkedBlockingQueue

class Reader(
    private val cacheRoot: File,
    private val onState: (ch: Int, idx: Int, done: Boolean) -> Unit,
    /** state: 0 running, 1 finished, 2 cancelled, 3 error */
    private val onPrep: (done: Int, total: Int, state: Int, msg: String) -> Unit
) {
    private class Pcm(val sr: Int, val s: ShortArray)
    private class Item(val c: Int, val i: Int, val pcm: Pcm?)
    private val END = Item(-1, -1, null)

    private var tts: OfflineTts? = null
    var chapters: List<Chapter> = emptyList()
    @Volatile var ch = 0
    @Volatile var idx = 0
    @Volatile var speed = 1.0f
    @Volatile var playing = false
    @Volatile var preparing = false
    @Volatile private var session = 0
    @Volatile private var threads: List<Thread> = emptyList()
    private var bookKey = "none"
    private var voiceTag = "none"
    val hasVoice get() = tts != null

    fun setBook(key: String) { bookKey = key }

    fun loadVoice(model: File, tokens: File, dataDir: File) {
        stop()
        threads.forEach { try { it.join() } catch (_: Exception) {} }
        tts?.release()
        tts = null
        val cfg = OfflineTtsConfig(
            model = OfflineTtsModelConfig(
                vits = OfflineTtsVitsModelConfig(
                    model = model.absolutePath,
                    tokens = tokens.absolutePath,
                    dataDir = dataDir.absolutePath
                ),
                numThreads = 2, debug = false, provider = "cpu"
            )
        )
        tts = OfflineTts(config = cfg)
        voiceTag = "${model.name}_${model.length()}".replace(Regex("[^A-Za-z0-9_.-]"), "_")
    }

    // ---------- audio cache (16-bit PCM on disk, generated at 1.0x speed) ----------
    private fun dir() = File(cacheRoot, "$bookKey-$voiceTag").apply { mkdirs() }
    private fun cacheFile(c: Int, i: Int) = File(dir(), "${c}_$i.pcm")

    private fun loadCached(c: Int, i: Int): Pcm? {
        val f = cacheFile(c, i)
        if (!f.exists() || f.length() < 4) return null
        return try {
            val b = f.readBytes()
            val bb = ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN)
            val sr = bb.int
            val s = ShortArray((b.size - 4) / 2)
            bb.asShortBuffer().get(s)
            Pcm(sr, s)
        } catch (_: Exception) { null }
    }

    private fun synth(t: OfflineTts, c: Int, i: Int): Pcm {
        val a = t.generate(chapters[c].chunks[i], 0, 1.0f)
        val s = ShortArray(a.samples.size) { (a.samples[it].coerceIn(-1f, 1f) * 32767f).toInt().toShort() }
        val pcm = Pcm(a.sampleRate, s)
        try {
            val f = cacheFile(c, i)
            val bb = ByteBuffer.allocate(4 + s.size * 2).order(ByteOrder.LITTLE_ENDIAN)
            bb.putInt(pcm.sr)
            bb.asShortBuffer().put(s)
            val tmp = File(f.path + ".tmp")
            tmp.writeBytes(bb.array())
            tmp.renameTo(f)
        } catch (_: Exception) {}
        return pcm
    }

    fun cacheBytes(): Long = cacheRoot.walkTopDown().filter { it.isFile }.sumOf { it.length() }

    fun clearCache() {
        stop()
        threads.forEach { try { it.join() } catch (_: Exception) {} }
        cacheRoot.deleteRecursively()
    }

    // ---------- prepare whole book ----------
    fun prepare() {
        val t = tts ?: return
        if (preparing || chapters.isEmpty()) return
        stop()
        preparing = true
        val s = session
        val old = threads
        val th = Thread {
            var done = 0
            var total = 0
            var state = 2
            var msg = ""
            try {
                old.forEach { try { it.join() } catch (_: InterruptedException) {} }
                val all = ArrayList<Pair<Int, Int>>()
                chapters.forEachIndexed { c, chap -> chap.chunks.indices.forEach { i -> all.add(c to i) } }
                total = all.size
                val start = all.indexOf(ch to idx).coerceAtLeast(0)
                for (k in 0 until total) {
                    if (session != s) break
                    val (c, i) = all[(start + k) % total]
                    if (!cacheFile(c, i).exists()) synth(t, c, i)
                    done++
                    if (done % 3 == 0) onPrep(done, total, 0, "")
                }
                state = if (done == total) 1 else 2
            } catch (e: Throwable) {
                state = 3; msg = e.message ?: "error"
            }
            preparing = false
            onPrep(done, total, state, msg)
        }
        threads = listOf(th)
        th.start()
    }

    // ---------- playback ----------
    fun play() {
        val t = tts ?: return
        if (playing || preparing || chapters.isEmpty()) return
        playing = true
        val s = ++session
        val old = threads
        val starter = Thread {
            old.forEach { try { it.join() } catch (_: InterruptedException) {} }
            if (session != s) return@Thread
            val q = LinkedBlockingQueue<Item>(6)

            val producer = Thread {
                try {
                    var c = ch; var i = idx
                    while (session == s) {
                        if (c >= chapters.size) { q.put(END); break }
                        if (i >= chapters[c].chunks.size) { c++; i = 0; continue }
                        val pcm = loadCached(c, i) ?: synth(t, c, i)
                        q.put(Item(c, i, pcm))
                        i++
                    }
                } catch (_: InterruptedException) {
                } catch (e: Throwable) {
                    if (session == s) { stop(); onPrep(0, 0, 3, e.message ?: "playback error") }
                }
            }

            val consumer = Thread {
                var track: AudioTrack? = null
                var finished = false
                var lastSpeed = -1f
                try {
                    while (session == s) {
                        val item = q.take()
                        val pcm = item.pcm
                        if (pcm == null) { finished = true; break }
                        if (track == null) track = newTrack(pcm.sr)
                        if (lastSpeed != speed) { applySpeed(track); lastSpeed = speed }
                        ch = item.c; idx = item.i
                        onState(item.c, item.i, false)
                        var p = 0
                        while (p < pcm.s.size && session == s) {
                            val n = minOf(4096, pcm.s.size - p)
                            track.write(pcm.s, p, n, AudioTrack.WRITE_BLOCKING)
                            p += n
                        }
                    }
                    if (finished && session == s) Thread.sleep(1500)
                } catch (_: InterruptedException) {
                } finally {
                    try { track?.stop() } catch (_: Exception) {}
                    try { track?.release() } catch (_: Exception) {}
                    if (session == s) {
                        playing = false
                        if (finished) { ch = 0; idx = 0; onState(0, 0, true) }
                    }
                }
            }
            threads = listOf(producer, consumer)
            producer.start(); consumer.start()
        }
        threads = listOf(starter)
        starter.start()
    }

    private fun newTrack(sr: Int): AudioTrack {
        val min = AudioTrack.getMinBufferSize(sr, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val tr = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setAudioFormat(AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(sr).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(maxOf(min, sr * 2))
            .setTransferMode(AudioTrack.MODE_STREAM).build()
        tr.play()
        return tr
    }

    private fun applySpeed(tr: AudioTrack) {
        try { tr.playbackParams = PlaybackParams().setSpeed(speed).setPitch(1.0f) } catch (_: Exception) {}
    }

    /** Stops playback or preparing. Position is kept. */
    fun stop() {
        session++
        playing = false
        threads.forEach { it.interrupt() }
    }

    fun jump(c: Int, i: Int = 0, autoplay: Boolean = false) {
        val was = playing || autoplay
        stop()
        ch = c.coerceIn(0, maxOf(0, chapters.size - 1))
        idx = i.coerceAtLeast(0)
        onState(ch, idx, false)
        if (was) play()
    }
}
