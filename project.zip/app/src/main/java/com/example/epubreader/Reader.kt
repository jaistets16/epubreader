package com.example.epubreader

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import com.k2fsa.sherpa.onnx.*
import java.io.File
import java.util.concurrent.LinkedBlockingQueue

class Reader(private val onState: (ch: Int, idx: Int, text: String, done: Boolean) -> Unit) {
    private class Item(val c: Int, val i: Int, val samples: FloatArray, val sr: Int)

    private var tts: OfflineTts? = null
    var chapters: List<List<String>> = emptyList()
    @Volatile var ch = 0
    @Volatile var idx = 0
    @Volatile var speed = 1.0f
    @Volatile var playing = false
    @Volatile private var session = 0
    private var threads = listOf<Thread>()
    val hasVoice get() = tts != null

    fun loadVoice(model: File, tokens: File, dataDir: File) {
        stop()
        tts?.release()
        val cfg = OfflineTtsConfig(
            model = OfflineTtsModelConfig(
                vits = OfflineTtsVitsModelConfig(
                    model = model.absolutePath,
                    tokens = tokens.absolutePath,
                    dataDir = dataDir.absolutePath
                ),
                numThreads = 2, debug = false, provider = "cpu"
            )
        )
        tts = OfflineTts(config = cfg)
    }

    fun play() {
        val t = tts ?: return
        if (playing || chapters.isEmpty()) return
        playing = true
        val s = ++session
        val q = LinkedBlockingQueue<Item>(3)
        val end = Item(-1, -1, FloatArray(0), 0)

        val producer = Thread {
            try {
                var c = ch; var i = idx
                while (session == s) {
                    if (c >= chapters.size) { q.put(end); break }
                    if (i >= chapters[c].size) { c++; i = 0; continue }
                    val a = t.generate(chapters[c][i], 0, speed)
                    q.put(Item(c, i, a.samples, a.sampleRate))
                    i++
                }
            } catch (_: InterruptedException) {}
        }
        val consumer = Thread {
            var track: AudioTrack? = null
            var finished = false
            try {
                while (session == s) {
                    val it = q.take()
                    if (it === end) { finished = true; break }
                    if (track == null) track = newTrack(it.sr)
                    ch = it.c; idx = it.i
                    onState(it.c, it.i, chapters[it.c][it.i], false)
                    var p = 0
                    while (p < it.samples.size && session == s) {
                        val n = minOf(4096, it.samples.size - p)
                        track.write(it.samples, p, n, AudioTrack.WRITE_BLOCKING)
                        p += n
                    }
                }
                if (finished && session == s) { track?.stop() }
            } catch (_: InterruptedException) {
            } finally {
                try { track?.release() } catch (_: Exception) {}
                if (session == s) { playing = false; if (finished) { ch = 0; idx = 0; onState(0, 0, "Finished", true) } }
            }
        }
        threads = listOf(producer, consumer)
        threads.forEach { it.start() }
    }

    private fun newTrack(sr: Int): AudioTrack {
        val min = AudioTrack.getMinBufferSize(sr, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_FLOAT)
        val tr = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setAudioFormat(AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_FLOAT)
                .setSampleRate(sr).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(maxOf(min, sr * 4))
            .setTransferMode(AudioTrack.MODE_STREAM).build()
        tr.play()
        return tr
    }

    /** Pause = stop; position is kept, so play() restarts the current chunk. */
    fun stop() {
        session++
        playing = false
        threads.forEach { it.interrupt() }
    }

    fun seek(chapter: Int, index: Int = 0) {
        val was = playing
        stop()
        ch = chapter.coerceIn(0, maxOf(0, chapters.size - 1)); idx = index
        if (chapters.isNotEmpty()) onState(ch, idx, chapters[ch].getOrElse(idx) { "" }, false)
        if (was) Thread { Thread.sleep(150); play() }.start()
    }
}
