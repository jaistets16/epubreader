package com.example.epubreader

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.documentfile.provider.DocumentFile
import java.io.File

class MainActivity : AppCompatActivity() {
    private lateinit var reader: Reader
    private lateinit var status: TextView
    private lateinit var chunkText: TextView
    private lateinit var playBtn: Button
    private val prefs by lazy { getSharedPreferences("p", 0) }
    private var bookId = ""

    private val pickEpub = registerForActivityResult(ActivityResultContracts.OpenDocument()) { it?.let(::openBook) }
    private val pickVoice = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { it?.let(::importVoice) }
    private val notifPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) {}

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        reader = Reader { c, i, t, done ->
            runOnUiThread {
                chunkText.text = t
                status.text = if (done) "Finished" else "Chapter ${c + 1}/${reader.chapters.size} · part ${i + 1}/${reader.chapters.getOrNull(c)?.size ?: 0}"
                if (bookId.isNotEmpty()) prefs.edit().putString("pos_$bookId", "$c:$i").apply()
                if (done) setPlaying(false)
            }
        }
        buildUi()
        if (Build.VERSION.SDK_INT >= 33) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        loadVoice()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 60, 40, 40) }
        fun btn(t: String, f: () -> Unit) = Button(this).apply {
            text = t; setOnClickListener { f() }
            layoutParams = LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f)
        }
        val row1 = LinearLayout(this)
        row1.addView(btn("Voice folder") { pickVoice.launch(null) })
        row1.addView(btn("Open EPUB") { pickEpub.launch(arrayOf("application/epub+zip", "*/*")) })
        status = TextView(this).apply { text = "Pick a Piper voice folder, then an EPUB."; setPadding(0, 24, 0, 24) }
        chunkText = TextView(this).apply { textSize = 18f }
        val scroll = ScrollView(this).apply { addView(chunkText); layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f) }
        val row2 = LinearLayout(this).apply { gravity = Gravity.CENTER }
        playBtn = btn("Play") { toggle() }
        row2.addView(btn("◀ Ch") { reader.seek(reader.ch - 1) })
        row2.addView(playBtn)
        row2.addView(btn("Ch ▶") { reader.seek(reader.ch + 1) })
        val speedLbl = TextView(this).apply { text = "Speed 1.0x" }
        val sb = SeekBar(this).apply {
            max = 15; progress = 5 // 0.5x..2.0x
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                    reader.speed = 0.5f + p / 10f; speedLbl.text = "Speed %.1fx".format(reader.speed)
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        listOf(row1, status, scroll, speedLbl, sb, row2).forEach { root.addView(it) }
        setContentView(root)
    }

    private fun toggle() {
        if (reader.playing) { reader.stop(); setPlaying(false); return }
        if (!reader.hasVoice) { toast("Pick a voice folder first"); return }
        if (reader.chapters.isEmpty()) { toast("Open an EPUB first"); return }
        reader.play(); setPlaying(true)
    }

    private fun setPlaying(p: Boolean) {
        playBtn.text = if (p) "Pause" else "Play"
        val i = Intent(this, KeepAliveService::class.java)
        if (p) startForegroundService(i) else stopService(i)
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()

    // ---- voice ----
    private fun importVoice(uri: Uri) {
        status.text = "Copying voice files…"
        Thread {
            try {
                val dest = File(filesDir, "voice"); dest.deleteRecursively(); dest.mkdirs()
                copyTree(DocumentFile.fromTreeUri(this, uri)!!, dest)
                runOnUiThread { loadVoice() }
            } catch (e: Exception) { runOnUiThread { status.text = "Voice copy failed: ${e.message}" } }
        }.start()
    }

    private fun copyTree(src: DocumentFile, dst: File) {
        for (f in src.listFiles()) {
            val name = f.name ?: continue
            if (f.isDirectory) copyTree(f, File(dst, name).also { it.mkdirs() })
            else contentResolver.openInputStream(f.uri)?.use { i -> File(dst, name).outputStream().use { i.copyTo(it) } }
        }
    }

    private fun loadVoice() {
        val dir = File(filesDir, "voice")
        if (!dir.exists()) return
        val all = dir.walkTopDown().toList()
        val model = all.firstOrNull { it.isFile && it.extension == "onnx" }
        val tokens = all.firstOrNull { it.isFile && it.name == "tokens.txt" }
        val data = all.firstOrNull { it.isDirectory && it.name == "espeak-ng-data" }
        if (model == null || tokens == null || data == null) {
            status.text = "Voice folder needs .onnx, tokens.txt and espeak-ng-data"; return
        }
        status.text = "Loading voice…"
        Thread {
            try {
                reader.loadVoice(model, tokens, data)
                runOnUiThread { status.text = "Voice ready. Open an EPUB." }
            } catch (e: Throwable) { runOnUiThread { status.text = "Voice load failed: ${e.message}" } }
        }.start()
    }

    // ---- book ----
    private fun openBook(uri: Uri) {
        status.text = "Reading EPUB…"
        reader.stop(); setPlaying(false)
        Thread {
            try {
                val name = contentResolver.query(uri, null, null, null, null)?.use {
                    if (it.moveToFirst()) it.getString(it.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME)) else null
                } ?: "book"
                val f = File(cacheDir, "book.epub")
                contentResolver.openInputStream(uri)!!.use { i -> f.outputStream().use { i.copyTo(it) } }
                val chapters = Epub.load(f)
                if (chapters.isEmpty()) error("No readable text")
                bookId = name.hashCode().toString()
                reader.chapters = chapters
                val pos = prefs.getString("pos_$bookId", "0:0")!!.split(":")
                val c = pos[0].toInt().coerceIn(0, chapters.size - 1)
                val i = pos[1].toInt().coerceAtLeast(0)
                runOnUiThread { reader.seek(c, i); toast("${chapters.size} chapters loaded (resumed)") }
            } catch (e: Throwable) { runOnUiThread { status.text = "EPUB failed: ${e.message}" } }
        }.start()
    }

    override fun onDestroy() { reader.stop(); super.onDestroy() }
}
