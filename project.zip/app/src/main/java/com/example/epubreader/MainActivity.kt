package com.example.epubreader

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.View
import android.view.ViewGroup
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.documentfile.provider.DocumentFile
import java.io.File

class MainActivity : AppCompatActivity() {
    private lateinit var reader: Reader
    private lateinit var status: TextView
    private lateinit var list: ListView
    private lateinit var playBtn: Button
    private lateinit var prepBtn: Button
    private val prefs by lazy { getSharedPreferences("p", 0) }
    private var bookId = ""
    private var bookName = ""
    private var voiceName = ""
    private var msg = ""
    private var shown = -1
    private var adapter: ChunkAdapter? = null

    private val pickEpub = registerForActivityResult(ActivityResultContracts.OpenDocument()) { it?.let(::openBook) }
    private val pickVoice = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { it?.let(::importVoice) }
    private val notifPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) {}

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        reader = Reader(
            File(filesDir, "audio"),
            onState = { c, i, done -> runOnUiThread { onReaderState(c, i, done) } },
            onPrep = { d, t, st, m -> runOnUiThread { onPrep(d, t, st, m) } }
        )
        buildUi()
        if (Build.VERSION.SDK_INT >= 33) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        loadVoice()
        val last = prefs.getString("last_book", null)
        if (last != null && File(last).exists())
            loadBook(File(last), prefs.getString("last_id", "") ?: "", prefs.getString("last_name", "") ?: "")
        refreshStatus()
    }

    // ---------- UI ----------
    private inner class ChunkAdapter(val items: List<String>) : BaseAdapter() {
        override fun getCount() = items.size
        override fun getItem(p: Int): Any = items[p]
        override fun getItemId(p: Int) = p.toLong()
        override fun getView(p: Int, v: View?, parent: ViewGroup?): View {
            val tv = (v as? TextView) ?: TextView(this@MainActivity).apply { textSize = 17f; setPadding(16, 14, 16, 14) }
            tv.text = items[p]
            tv.setBackgroundColor(if (shown == reader.ch && p == reader.idx) 0x55FFC107 else 0)
            return tv
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 48, 24, 24) }
        fun btn(t: String, f: () -> Unit) = Button(this).apply {
            text = t; isAllCaps = false; textSize = 13f; setOnClickListener { f() }
            layoutParams = LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f)
        }
        val row1 = LinearLayout(this)
        row1.addView(btn("Voice folder") { pickVoice.launch(null) })
        row1.addView(btn("Open EPUB") { pickEpub.launch(arrayOf("application/epub+zip", "*/*")) })

        status = TextView(this).apply { setPadding(0, 16, 0, 16) }

        list = ListView(this).apply {
            layoutParams = LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f)
            setOnItemClickListener { _, _, pos, _ -> startFrom(shown, pos) }
        }

        val row2 = LinearLayout(this)
        row2.addView(btn("Chapters") { showChapters() })
        prepBtn = btn("Prepare book") { togglePrepare() }
        row2.addView(prepBtn)
        row2.addView(btn("Clear audio") { clearAudio() })

        val speedLbl = TextView(this).apply { text = "Speed 1.0x"; setPadding(0, 12, 0, 0) }
        val sb = SeekBar(this).apply {
            max = 15; progress = 5 // 0.5x..2.0x
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                    reader.speed = 0.5f + p / 10f; speedLbl.text = "Speed %.1fx".format(reader.speed)
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }

        val row3 = LinearLayout(this)
        row3.addView(btn("◀ Ch") { if (guard()) reader.jump(reader.ch - 1) })
        playBtn = btn("Play") { toggle() }
        row3.addView(playBtn)
        row3.addView(btn("Ch ▶") { if (guard()) reader.jump(reader.ch + 1) })

        listOf(row1, status, list, row2, speedLbl, sb, row3).forEach { root.addView(it) }
        setContentView(root)
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()

    private fun guard(): Boolean {
        if (reader.preparing) { toast("Preparing audio. Tap 'Cancel prep' first."); return false }
        return true
    }

    private fun refreshStatus() {
        val chs = reader.chapters
        var pos = ""
        if (chs.isNotEmpty()) {
            val c = reader.ch.coerceIn(0, chs.size - 1)
            pos = "\nChapter ${c + 1}/${chs.size}: ${chs[c].title}\nPart ${reader.idx + 1}/${chs[c].chunks.size}"
        }
        status.text = "${voiceName.ifEmpty { "No voice" }} · ${bookName.ifEmpty { "No book" }}$pos" +
            if (msg.isNotEmpty()) "\n$msg" else ""
    }

    private fun showChapter(c: Int) {
        if (c != shown && c in reader.chapters.indices) {
            shown = c
            adapter = ChunkAdapter(reader.chapters[c].chunks)
            list.adapter = adapter
        }
    }

    private fun onReaderState(c: Int, i: Int, done: Boolean) {
        if (bookId.isNotEmpty()) prefs.edit().putString("pos_$bookId", "$c:$i").apply()
        showChapter(c)
        adapter?.notifyDataSetChanged()
        if (reader.playing) list.smoothScrollToPosition(i)
        if (done) { setPlaying(false); msg = "Finished" }
        refreshStatus()
    }

    private fun onPrep(done: Int, total: Int, state: Int, m: String) {
        when (state) {
            0 -> { msg = "Preparing audio: $done/$total (${done * 100 / maxOf(total, 1)}%)"; prepBtn.text = "Cancel prep" }
            1 -> { msg = "Whole book ready (${reader.cacheBytes() / 1_000_000} MB). Press Play."; prepBtn.text = "Prepare book"; keepAlive(reader.playing) }
            2 -> { msg = "Preparing cancelled ($done/$total). Finished parts are kept."; prepBtn.text = "Prepare book"; keepAlive(reader.playing) }
            else -> { msg = "Error: $m"; prepBtn.text = "Prepare book"; setPlaying(false) }
        }
        refreshStatus()
    }

    private fun keepAlive(on: Boolean) {
        val i = Intent(this, KeepAliveService::class.java)
        if (on) startForegroundService(i) else stopService(i)
    }

    private fun setPlaying(p: Boolean) {
        playBtn.text = if (p) "Pause" else "Play"
        keepAlive(p || reader.preparing)
    }

    private fun toggle() {
        if (reader.playing) { reader.stop(); setPlaying(false); return }
        if (!guard()) return
        if (!reader.hasVoice) { toast("Pick a voice folder first"); return }
        if (reader.chapters.isEmpty()) { toast("Open an EPUB first"); return }
        msg = ""
        reader.play(); setPlaying(true)
    }

    private fun startFrom(c: Int, i: Int) {
        if (!guard()) return
        if (!reader.hasVoice) { toast("Pick a voice folder first"); return }
        if (c < 0) return
        msg = ""
        reader.jump(c, i, true); setPlaying(true)
    }

    private fun showChapters() {
        if (reader.chapters.isEmpty()) { toast("Open an EPUB first"); return }
        if (!guard()) return
        val titles = reader.chapters.mapIndexed { i, c -> "${i + 1}. ${c.title}" }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Chapters")
            .setItems(titles) { _, w -> reader.jump(w, 0) }
            .show()
    }

    private fun togglePrepare() {
        if (reader.preparing) { reader.stop(); return }
        if (!reader.hasVoice) { toast("Pick a voice folder first"); return }
        if (reader.chapters.isEmpty()) { toast("Open an EPUB first"); return }
        AlertDialog.Builder(this).setTitle("Prepare whole book?")
            .setMessage("Converts the entire book to audio first so playback never pauses. " +
                "It can take a long time and uses phone storage (roughly 100-160 MB per hour of audio). " +
                "Keep the phone charging and don't close the app. Starts from your current position.")
            .setPositiveButton("Start") { _, _ ->
                setPlaying(false)
                msg = "Preparing audio…"; prepBtn.text = "Cancel prep"
                keepAlive(true)
                reader.prepare()
                refreshStatus()
            }
            .setNegativeButton("Not now", null).show()
    }

    private fun clearAudio() {
        if (!guard()) return
        val mb = reader.cacheBytes() / 1_000_000
        AlertDialog.Builder(this).setTitle("Delete prepared audio?")
            .setMessage("Frees about $mb MB. Audio is re-created when you play or prepare again.")
            .setPositiveButton("Delete") { _, _ ->
                setPlaying(false)
                Thread { reader.clearCache(); runOnUiThread { msg = "Prepared audio deleted"; refreshStatus() } }.start()
            }
            .setNegativeButton("Cancel", null).show()
    }

    // ---------- voice ----------
    private fun importVoice(uri: Uri) {
        msg = "Copying voice files…"; refreshStatus()
        reader.stop(); setPlaying(false)
        Thread {
            try {
                val dest = File(filesDir, "voice"); dest.deleteRecursively(); dest.mkdirs()
                copyTree(DocumentFile.fromTreeUri(this, uri)!!, dest)
                runOnUiThread { loadVoice() }
            } catch (e: Exception) { runOnUiThread { msg = "Voice copy failed: ${e.message}"; refreshStatus() } }
        }.start()
    }

    private fun copyTree(src: DocumentFile, dst: File) {
        for (f in src.listFiles()) {
            val name = f.name ?: continue
            if (f.isDirectory) copyTree(f, File(dst, name).also { it.mkdirs() })
            else contentResolver.openInputStream(f.uri)?.use { i -> File(dst, name).outputStream().use { i.copyTo(it) } }
        }
    }

    private fun loadVoice() {
        val dir = File(filesDir, "voice")
        if (!dir.exists()) return
        val all = dir.walkTopDown().toList()
        val model = all.firstOrNull { it.isFile && it.extension == "onnx" }
        val tokens = all.firstOrNull { it.isFile && it.name == "tokens.txt" }
        val data = all.firstOrNull { it.isDirectory && it.name == "espeak-ng-data" }
        if (model == null || tokens == null || data == null) {
            msg = "Voice folder needs .onnx, tokens.txt and espeak-ng-data"; refreshStatus(); return
        }
        msg = "Loading voice…"; refreshStatus()
        Thread {
            try {
                reader.loadVoice(model, tokens, data)
                runOnUiThread { voiceName = model.parentFile?.name ?: model.name; msg = ""; refreshStatus() }
            } catch (e: Throwable) { runOnUiThread { msg = "Voice load failed: ${e.message}"; refreshStatus() } }
        }.start()
    }

    // ---------- book ----------
    private fun openBook(uri: Uri) {
        msg = "Reading EPUB…"; refreshStatus()
        reader.stop(); setPlaying(false)
        Thread {
            try {
                val name = contentResolver.query(uri, null, null, null, null)?.use {
                    if (it.moveToFirst()) it.getString(it.getColumnIndexOrThrow(OpenableColumns.DISPLAY_NAME)) else null
                } ?: "book"
                val id = name.hashCode().toString()
                val dir = File(filesDir, "books").apply { mkdirs() }
                val f = File(dir, "$id.epub")
                contentResolver.openInputStream(uri)!!.use { i -> f.outputStream().use { i.copyTo(it) } }
                prefs.edit().putString("last_book", f.absolutePath).putString("last_id", id).putString("last_name", name).apply()
                loadBook(f, id, name)
            } catch (e: Throwable) { runOnUiThread { msg = "EPUB failed: ${e.message}"; refreshStatus() } }
        }.start()
    }

    private fun loadBook(file: File, id: String, name: String) {
        Thread {
            try {
                val chapters = Epub.load(file)
                if (chapters.isEmpty()) error("No readable text")
                runOnUiThread {
                    reader.stop(); setPlaying(false)
                    bookId = id; bookName = name; msg = ""
                    reader.chapters = chapters
                    reader.setBook(id)
                    shown = -1
                    val pos = (prefs.getString("pos_$id", "0:0") ?: "0:0").split(":")
                    reader.jump((pos.getOrNull(0)?.toIntOrNull() ?: 0).coerceIn(0, chapters.size - 1),
                        pos.getOrNull(1)?.toIntOrNull() ?: 0)
                    toast("${chapters.size} chapters loaded")
                }
            } catch (e: Throwable) { runOnUiThread { msg = "EPUB failed: ${e.message}"; refreshStatus() } }
        }.start()
    }

    override fun onDestroy() { reader.stop(); super.onDestroy() }
}
